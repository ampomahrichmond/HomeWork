import os
import uuid
import pandas as pd
from flask import render_template, request, redirect, url_for, flash, send_file, jsonify, current_app
from werkzeug.utils import secure_filename
from app import app, db
from models import ExcelFile, ExcelSheet, ProcessingJob, DataLineage
from excel_processor import ExcelProcessor
from data_cleaner import DataCleaner
from lineage_tracker import LineageTracker
import logging

logger = logging.getLogger(__name__)

ALLOWED_EXTENSIONS = {'xlsx', 'xls'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Main dashboard showing uploaded files and recent jobs"""
    excel_files = ExcelFile.query.order_by(ExcelFile.upload_date.desc()).limit(10).all()
    recent_jobs = ProcessingJob.query.order_by(ProcessingJob.created_date.desc()).limit(5).all()
    return render_template('index.html', excel_files=excel_files, recent_jobs=recent_jobs)

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    """Handle Excel file upload"""
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected', 'error')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            try:
                # Generate secure filename
                original_filename = file.filename
                filename = str(uuid.uuid4()) + '_' + secure_filename(file.filename)
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                
                # Save file
                file.save(file_path)
                
                # Process Excel file to get sheet information
                processor = ExcelProcessor(file_path)
                sheets_info = processor.get_sheets_info()
                
                # Create database record
                excel_file = ExcelFile(
                    filename=filename,
                    original_filename=original_filename,
                    file_path=file_path,
                    sheet_count=len(sheets_info)
                )
                db.session.add(excel_file)
                db.session.commit()
                
                # Create sheet records
                for sheet_info in sheets_info:
                    excel_sheet = ExcelSheet(
                        excel_file_id=excel_file.id,
                        sheet_name=sheet_info['name'],
                        row_count=sheet_info['row_count'],
                        column_count=sheet_info['column_count']
                    )
                    excel_sheet.set_headers(sheet_info['headers'])
                    db.session.add(excel_sheet)
                
                db.session.commit()
                
                flash(f'File uploaded successfully! Found {len(sheets_info)} sheets.', 'success')
                return redirect(url_for('view_sheets', file_id=excel_file.id))
                
            except Exception as e:
                logger.error(f"Error processing uploaded file: {str(e)}")
                flash(f'Error processing file: {str(e)}', 'error')
                return redirect(request.url)
        else:
            flash('Invalid file type. Please upload Excel files (.xlsx or .xls)', 'error')
    
    return render_template('upload.html')

@app.route('/sheets/<int:file_id>')
def view_sheets(file_id):
    """View sheets in an Excel file"""
    excel_file = ExcelFile.query.get_or_404(file_id)
    
    # Get sheet data with preview
    processor = ExcelProcessor(excel_file.file_path)
    sheets_data = []
    
    for sheet in excel_file.sheets:
        preview_data = processor.get_sheet_preview(sheet.sheet_name, rows=5)
        sheets_data.append({
            'sheet': sheet,
            'preview_data': preview_data
        })
    
    return render_template('sheets.html', excel_file=excel_file, sheets_data=sheets_data)

@app.route('/clean_sheet/<int:sheet_id>')
def clean_sheet(sheet_id):
    """Clean a specific sheet"""
    sheet = ExcelSheet.query.get_or_404(sheet_id)
    
    try:
        # Get the processor and cleaner
        processor = ExcelProcessor(sheet.excel_file.file_path)
        cleaner = DataCleaner()
        
        # Get original data
        original_data = processor.get_sheet_data(sheet.sheet_name)
        
        # Clean the data
        cleaned_data = cleaner.clean_dataframe(original_data)
        
        # Show before/after comparison
        preview_original = original_data.head(10).to_dict('records') if not original_data.empty else []
        preview_cleaned = cleaned_data.head(10).to_dict('records') if not cleaned_data.empty else []
        
        return render_template('clean_preview.html', 
                             sheet=sheet,
                             original_data=preview_original,
                             cleaned_data=preview_cleaned,
                             original_columns=list(original_data.columns) if not original_data.empty else [],
                             cleaned_columns=list(cleaned_data.columns) if not cleaned_data.empty else [])
        
    except Exception as e:
        logger.error(f"Error cleaning sheet {sheet_id}: {str(e)}")
        flash(f'Error cleaning sheet: {str(e)}', 'error')
        return redirect(url_for('view_sheets', file_id=sheet.excel_file_id))

@app.route('/combine_sheets', methods=['GET', 'POST'])
def combine_sheets():
    """Combine multiple sheets with intelligent joining"""
    if request.method == 'POST':
        try:
            # Get form data
            selected_sheet_ids = request.form.getlist('selected_sheets')
            join_type = request.form.get('join_type', 'concat')  # concat, inner, left, right, outer
            join_columns = request.form.getlist('join_columns')
            clean_data = request.form.get('clean_data') == 'on'
            track_lineage = request.form.get('track_lineage') == 'on'
            
            if len(selected_sheet_ids) < 2:
                flash('Please select at least 2 sheets to combine', 'error')
                return redirect(request.url)
            
            # Create processing job
            job = ProcessingJob(
                job_name=f"Combine {len(selected_sheet_ids)} sheets",
                status='running'
            )
            job.set_selected_sheets([int(id) for id in selected_sheet_ids])
            job.set_join_criteria({
                'join_type': join_type,
                'join_columns': join_columns
            })
            db.session.add(job)
            db.session.commit()
            
            # Process the combination
            result_file = process_combination_job(job.id)
            
            if result_file:
                job.status = 'completed'
                job.result_file_path = result_file
                flash('Sheets combined successfully!', 'success')
            else:
                job.status = 'error'
                job.error_message = 'Failed to combine sheets'
                flash('Error combining sheets', 'error')
            
            db.session.commit()
            return redirect(url_for('view_job', job_id=job.id))
            
        except Exception as e:
            logger.error(f"Error combining sheets: {str(e)}")
            flash(f'Error combining sheets: {str(e)}', 'error')
    
    # Get all available files and sheets with enhanced information
    excel_files = ExcelFile.query.order_by(ExcelFile.upload_date.desc()).all()
    
    # Prepare sheet data with column information for intelligent joining
    sheets_with_columns = []
    for excel_file in excel_files:
        for sheet in excel_file.sheets:
            try:
                processor = ExcelProcessor(excel_file.file_path)
                preview_data = processor.get_sheet_preview(sheet.sheet_name, rows=5)
                if isinstance(preview_data, dict):
                    columns = preview_data.get('headers', [])
                else:
                    columns = list(preview_data.columns) if hasattr(preview_data, 'columns') and not preview_data.empty else []
                
                sheets_with_columns.append({
                    'sheet_id': sheet.id,
                    'sheet_name': sheet.sheet_name,
                    'file_name': excel_file.original_filename,
                    'file_id': excel_file.id,
                    'columns': columns,
                    'row_count': sheet.row_count or 0,
                    'column_count': sheet.column_count or 0
                })
            except Exception as e:
                logger.error(f"Error getting sheet info for {sheet.sheet_name}: {str(e)}")
                sheets_with_columns.append({
                    'sheet_id': sheet.id,
                    'sheet_name': sheet.sheet_name,
                    'file_name': excel_file.original_filename,
                    'file_id': excel_file.id,
                    'columns': [],
                    'row_count': sheet.row_count or 0,
                    'column_count': sheet.column_count or 0
                })
    
    return render_template('combine.html', excel_files=excel_files, sheets_with_columns=sheets_with_columns)

@app.route('/job/<int:job_id>')
def view_job(job_id):
    """View processing job details and results"""
    job = ProcessingJob.query.get_or_404(job_id)
    
    # Get lineage information
    lineage_tracker = LineageTracker()
    lineage_data = lineage_tracker.get_job_lineage(job_id)
    
    return render_template('job_details.html', job=job, lineage_data=lineage_data)

@app.route('/lineage/<int:job_id>')
def view_lineage(job_id):
    """View data lineage visualization"""
    job = ProcessingJob.query.get_or_404(job_id)
    
    # Get lineage data for visualization
    lineage_tracker = LineageTracker()
    lineage_graph = lineage_tracker.generate_lineage_graph(job_id)
    
    return render_template('lineage.html', job=job, lineage_graph=lineage_graph)

@app.route('/download/<int:job_id>')
def download_result(job_id):
    """Download the result file from a processing job"""
    job = ProcessingJob.query.get_or_404(job_id)
    
    if job.status != 'completed' or not job.result_file_path:
        flash('No result file available for this job', 'error')
        return redirect(url_for('view_job', job_id=job_id))
    
    if not os.path.exists(job.result_file_path):
        flash('Result file not found', 'error')
        return redirect(url_for('view_job', job_id=job_id))
    
    return send_file(job.result_file_path, as_attachment=True,
                     download_name=f"{job.job_name}_result.xlsx")

def process_combination_job(job_id):
    """Process a sheet combination job"""
    try:
        job = ProcessingJob.query.get(job_id)
        if not job:
            logger.error(f"Job {job_id} not found")
            return None
        
        selected_sheet_ids = job.get_selected_sheets()
        join_criteria = job.get_join_criteria()
        logger.info(f"Processing job {job_id} with sheets: {selected_sheet_ids}")
        
        # Get sheets data
        sheets = ExcelSheet.query.filter(ExcelSheet.id.in_(selected_sheet_ids)).all()
        
        if not sheets:
            logger.error(f"No sheets found for IDs: {selected_sheet_ids}")
            return None
        
        # Initialize processors and cleaners
        combined_data = None
        lineage_tracker = LineageTracker()
        dataframes_to_combine = []
        
        for i, sheet in enumerate(sheets):
            try:
                logger.info(f"Processing sheet: {sheet.sheet_name}")
                processor = ExcelProcessor(sheet.excel_file.file_path)
                cleaner = DataCleaner()
                
                # Get and clean sheet data
                sheet_data = processor.get_sheet_data(sheet.sheet_name)
                
                if sheet_data is None or sheet_data.empty:
                    logger.warning(f"Sheet {sheet.sheet_name} is empty, skipping")
                    continue
                
                cleaned_data = cleaner.clean_dataframe(sheet_data)
                dataframes_to_combine.append(cleaned_data)
                
                # Track lineage
                lineage_tracker.track_cleaning(job_id, sheet.id, sheet_data.columns.tolist(), cleaned_data.columns.tolist())
                
            except Exception as e:
                logger.error(f"Error processing sheet {sheet.sheet_name}: {str(e)}")
                continue
        
        # Check if we have any data to combine
        if not dataframes_to_combine:
            logger.error("No valid dataframes to combine")
            return None
        
        # Combine the dataframes
        join_type = join_criteria.get('join_type', 'concat')
        logger.info(f"Combining {len(dataframes_to_combine)} dataframes using {join_type}")
        
        if join_type == 'concat' or len(dataframes_to_combine) == 1:
            # Simple concatenation
            combined_data = pd.concat(dataframes_to_combine, ignore_index=True)
            for sheet in sheets:
                lineage_tracker.track_concatenation(job_id, sheet.id)
        else:
            # Join operations
            combined_data = dataframes_to_combine[0]
            join_columns = join_criteria.get('join_columns', [])
            
            for i in range(1, len(dataframes_to_combine)):
                df_to_join = dataframes_to_combine[i]
                
                if join_columns:
                    # Find common columns
                    common_cols = list(set(combined_data.columns) & set(df_to_join.columns) & set(join_columns))
                    if common_cols:
                        combined_data = combined_data.merge(df_to_join, on=common_cols, how=join_type, suffixes=('', f'_sheet{i+1}'))
                        lineage_tracker.track_join(job_id, sheets[i].id, common_cols, join_type)
                else:
                    # No join columns, concatenate
                    combined_data = pd.concat([combined_data, df_to_join], ignore_index=True)
                    lineage_tracker.track_concatenation(job_id, sheets[i].id)
        
        # Ensure processed folder exists
        processed_folder = current_app.config.get('PROCESSED_FOLDER', 'processed')
        os.makedirs(processed_folder, exist_ok=True)
        
        # Save result file
        result_filename = f"combined_{job_id}_{uuid.uuid4().hex[:8]}.xlsx"
        result_file_path = os.path.join(processed_folder, result_filename)
        
        combined_data.to_excel(result_file_path, index=False)
        logger.info(f"Combined data saved to: {result_file_path}")
        
        return result_file_path
        
    except Exception as e:
        logger.error(f"Error processing combination job {job_id}: {str(e)}")
        return None

@app.errorhandler(413)
def too_large(e):
    flash('File is too large. Maximum size is 50MB.', 'error')
    return redirect(url_for('upload_file'))
