/**
 * Excel Data Processor - Main JavaScript
 * TD Green themed intelligent multi-sheet Excel processing application
 */

// Global application state
window.ExcelProcessor = {
    config: {
        theme: 'td-green',
        debug: true,
        maxFileSize: 50 * 1024 * 1024, // 50MB
        allowedExtensions: ['.xlsx', '.xls'],
        apiEndpoints: {
            upload: '/upload',
            combine: '/combine_sheets',
            clean: '/clean_sheet',
            lineage: '/lineage'
        }
    },
    state: {
        selectedSheets: [],
        currentJob: null,
        uploadInProgress: false,
        processingInProgress: false
    },
    utils: {},
    components: {}
};

// Utility Functions
window.ExcelProcessor.utils = {
    /**
     * Format file size in human readable format
     */
    formatFileSize: function(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    /**
     * Validate file type
     */
    validateFileType: function(filename) {
        const extension = '.' + filename.split('.').pop().toLowerCase();
        return this.config.allowedExtensions.includes(extension);
    },

    /**
     * Show loading state
     */
    showLoading: function(message = 'Processing...') {
        if (document.getElementById('loadingOverlay')) {
            this.hideLoading();
        }

        const overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-light mb-3" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <div class="loading-text">${message}</div>
            </div>
        `;
        document.body.appendChild(overlay);
    },

    /**
     * Hide loading state
     */
    hideLoading: function() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.remove();
        }
    },

    /**
     * Show notification
     */
    showNotification: function(message, type = 'info', duration = 5000) {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 10000; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto-remove after duration
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, duration);
    },

    /**
     * Debounce function
     */
    debounce: function(func, wait, immediate) {
        let timeout;
        return function executedFunction() {
            const context = this;
            const args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    },

    /**
     * Generate unique ID
     */
    generateId: function() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    },

    /**
     * Deep clone object
     */
    deepClone: function(obj) {
        if (obj === null || typeof obj !== 'object') return obj;
        if (obj instanceof Date) return new Date(obj.getTime());
        if (obj instanceof Array) return obj.map(item => this.deepClone(item));
        if (typeof obj === 'object') {
            const clonedObj = {};
            for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                    clonedObj[key] = this.deepClone(obj[key]);
                }
            }
            return clonedObj;
        }
    },

    /**
     * Check if element is in viewport
     */
    isInViewport: function(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
};

// File Upload Component
window.ExcelProcessor.components.FileUpload = {
    init: function() {
        this.setupDragAndDrop();
        this.setupFileInput();
        this.setupProgressTracking();
    },

    setupDragAndDrop: function() {
        const uploadArea = document.getElementById('uploadArea');
        if (!uploadArea) return;

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, this.preventDefaults, false);
            document.body.addEventListener(eventName, this.preventDefaults, false);
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => uploadArea.classList.add('drag-over'), false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => uploadArea.classList.remove('drag-over'), false);
        });

        uploadArea.addEventListener('drop', this.handleDrop.bind(this), false);
    },

    setupFileInput: function() {
        const fileInput = document.getElementById('fileInput');
        const browseBtn = document.getElementById('browseBtn');

        if (browseBtn && fileInput) {
            browseBtn.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', this.handleFileSelect.bind(this));
        }
    },

    setupProgressTracking: function() {
        const form = document.getElementById('uploadForm');
        if (form) {
            form.addEventListener('submit', this.handleFormSubmit.bind(this));
        }
    },

    preventDefaults: function(e) {
        e.preventDefault();
        e.stopPropagation();
    },

    handleDrop: function(e) {
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    },

    handleFileSelect: function(e) {
        if (e.target.files.length > 0) {
            this.processFile(e.target.files[0]);
        }
    },

    processFile: function(file) {
        // Validate file type
        if (!window.ExcelProcessor.utils.validateFileType(file.name)) {
            window.ExcelProcessor.utils.showNotification(
                'Please select a valid Excel file (.xlsx or .xls)', 
                'danger'
            );
            return;
        }

        // Validate file size
        if (file.size > window.ExcelProcessor.config.maxFileSize) {
            window.ExcelProcessor.utils.showNotification(
                'File size must be less than 50MB', 
                'danger'
            );
            return;
        }

        // Update UI
        this.updateFileInfo(file);
        this.showUploadButton();
    },

    updateFileInfo: function(file) {
        const fileName = document.getElementById('fileName');
        const fileSize = document.getElementById('fileSize');
        const fileInfo = document.getElementById('fileInfo');

        if (fileName && fileSize && fileInfo) {
            fileName.textContent = file.name;
            fileSize.textContent = window.ExcelProcessor.utils.formatFileSize(file.size);
            fileInfo.style.display = 'block';
        }
    },

    showUploadButton: function() {
        const uploadBtn = document.getElementById('uploadBtn');
        if (uploadBtn) {
            uploadBtn.style.display = 'inline-block';
        }
    },

    handleFormSubmit: function(e) {
        e.preventDefault();
        
        const fileInput = document.getElementById('fileInput');
        if (!fileInput.files[0]) {
            window.ExcelProcessor.utils.showNotification('Please select a file first', 'warning');
            return;
        }

        this.uploadFile(fileInput.files[0]);
    },

    uploadFile: function(file) {
        const formData = new FormData();
        formData.append('file', file);

        // Show progress
        this.showProgress();
        window.ExcelProcessor.state.uploadInProgress = true;

        // Upload file
        fetch('/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (response.ok) {
                return response.url;
            }
            throw new Error('Upload failed');
        })
        .then(url => {
            window.ExcelProcessor.utils.hideLoading();
            window.ExcelProcessor.utils.showNotification('File uploaded successfully!', 'success');
            window.location.href = url;
        })
        .catch(error => {
            console.error('Upload error:', error);
            window.ExcelProcessor.utils.hideLoading();
            window.ExcelProcessor.utils.showNotification('Upload failed. Please try again.', 'danger');
            this.resetUploadState();
        })
        .finally(() => {
            window.ExcelProcessor.state.uploadInProgress = false;
        });
    },

    showProgress: function() {
        window.ExcelProcessor.utils.showLoading('Uploading and processing file...');
        
        const uploadBtn = document.getElementById('uploadBtn');
        if (uploadBtn) {
            uploadBtn.disabled = true;
            uploadBtn.innerHTML = '<i data-feather="loader" class="me-2"></i>Processing...';
        }
    },

    resetUploadState: function() {
        const uploadBtn = document.getElementById('uploadBtn');
        if (uploadBtn) {
            uploadBtn.disabled = false;
            uploadBtn.innerHTML = '<i data-feather="upload-cloud" class="me-2"></i>Upload and Process';
        }
        
        // Re-initialize feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    }
};

// Sheet Selection Component
window.ExcelProcessor.components.SheetSelection = {
    init: function() {
        this.setupSheetCheckboxes();
        this.setupJoinTypeRadios();
        this.setupCombineForm();
        this.updateSelectionState();
    },

    setupSheetCheckboxes: function() {
        const checkboxes = document.querySelectorAll('.sheet-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', this.handleSheetSelection.bind(this));
        });
    },

    setupJoinTypeRadios: function() {
        const radios = document.querySelectorAll('input[name="join_type"]');
        radios.forEach(radio => {
            radio.addEventListener('change', this.handleJoinTypeChange.bind(this));
        });
    },

    setupCombineForm: function() {
        const form = document.getElementById('combineForm');
        if (form) {
            form.addEventListener('submit', this.handleCombineSubmit.bind(this));
        }
    },

    handleSheetSelection: function() {
        this.updateSelectedSheets();
        this.updateJoinColumns();
        this.updateCombineButton();
        this.updateStats();
    },

    handleJoinTypeChange: function() {
        this.updateJoinColumns();
    },

    updateSelectedSheets: function() {
        const checkboxes = document.querySelectorAll('.sheet-checkbox:checked');
        window.ExcelProcessor.state.selectedSheets = Array.from(checkboxes).map(cb => ({
            id: parseInt(cb.value),
            name: cb.dataset.sheetName,
            fileId: cb.dataset.fileId,
            headers: JSON.parse(cb.dataset.headers || '[]')
        }));

        this.updateSelectedInfo();
    },

    updateSelectedInfo: function() {
        const selectedSheetsList = document.getElementById('selectedSheetsList');
        if (!selectedSheetsList) return;

        const selectedSheets = window.ExcelProcessor.state.selectedSheets;
        
        if (selectedSheets.length === 0) {
            selectedSheetsList.innerHTML = '<small class="text-muted">No sheets selected</small>';
        } else {
            const html = selectedSheets.map(sheet => 
                `<div class="badge bg-td-green me-1 mb-1">${sheet.name}</div>`
            ).join('');
            selectedSheetsList.innerHTML = html;
        }
    },

    updateJoinColumns: function() {
        const joinColumnsContainer = document.getElementById('joinColumnsContainer');
        if (!joinColumnsContainer) return;

        const selectedSheets = window.ExcelProcessor.state.selectedSheets;
        const joinType = document.querySelector('input[name="join_type"]:checked')?.value || 'inner';
        
        if (joinType === 'concat' || selectedSheets.length < 2) {
            joinColumnsContainer.innerHTML = joinType === 'concat' ? 
                '<small class="text-muted">No join columns needed for concatenation</small>' :
                '<small class="text-muted">Select at least 2 sheets to see join columns</small>';
            return;
        }

        // Find common columns
        let commonColumns = selectedSheets[0].headers.slice();
        for (let i = 1; i < selectedSheets.length; i++) {
            commonColumns = commonColumns.filter(col => selectedSheets[i].headers.includes(col));
        }

        if (commonColumns.length === 0) {
            joinColumnsContainer.innerHTML = 
                '<div class="alert alert-warning py-2">No common columns found. Consider using concatenation.</div>';
        } else {
            let html = '<small class="text-muted mb-2 d-block">Available join columns:</small>';
            commonColumns.forEach(col => {
                html += `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="join_columns" value="${col}" id="join_col_${col}">
                        <label class="form-check-label" for="join_col_${col}">
                            ${col}
                        </label>
                    </div>
                `;
            });
            joinColumnsContainer.innerHTML = html;
        }
    },

    updateCombineButton: function() {
        const combineBtn = document.getElementById('combineBtn');
        if (combineBtn) {
            combineBtn.disabled = window.ExcelProcessor.state.selectedSheets.length < 2;
        }
    },

    updateStats: function() {
        const selectedCount = document.getElementById('selectedCount');
        if (selectedCount) {
            selectedCount.textContent = window.ExcelProcessor.state.selectedSheets.length;
        }
    },

    updateSelectionState: function() {
        this.updateSelectedSheets();
        this.updateJoinColumns();
        this.updateCombineButton();
        this.updateStats();
    },

    handleCombineSubmit: function(e) {
        const selectedSheets = window.ExcelProcessor.state.selectedSheets;
        
        if (selectedSheets.length < 2) {
            e.preventDefault();
            window.ExcelProcessor.utils.showNotification(
                'Please select at least 2 sheets to combine', 
                'warning'
            );
            return;
        }

        window.ExcelProcessor.utils.showLoading('Combining sheets...');
        window.ExcelProcessor.state.processingInProgress = true;
    }
};

// Data Lineage Visualization Component
window.ExcelProcessor.components.LineageVisualization = {
    network: null,
    nodes: null,
    edges: null,

    init: function() {
        this.initializeNetwork();
        this.setupControls();
    },

    initializeNetwork: function() {
        const container = document.getElementById('lineageNetwork');
        const dataElement = document.getElementById('lineageData');
        
        if (!container || !dataElement) return;

        try {
            const lineageData = JSON.parse(dataElement.textContent);
            this.createNetworkVisualization(container, lineageData);
        } catch (error) {
            console.error('Error initializing lineage graph:', error);
            this.showError(container);
        }
    },

    createNetworkVisualization: function(container, lineageData) {
        // Prepare nodes and edges for vis.js
        this.nodes = new vis.DataSet(lineageData.nodes.map(node => ({
            id: node.id,
            label: node.label,
            color: node.color,
            font: { color: '#333', size: 12 },
            shape: this.getNodeShape(node.type),
            size: this.getNodeSize(node.type)
        })));
        
        this.edges = new vis.DataSet(lineageData.edges.map(edge => ({
            from: edge.from,
            to: edge.to,
            label: edge.label || '',
            color: edge.color || '#666',
            arrows: 'to',
            font: { size: 10, color: '#666' }
        })));

        const data = { nodes: this.nodes, edges: this.edges };
        const options = this.getNetworkOptions();
        
        this.network = new vis.Network(container, data, options);
        this.setupNetworkEvents();
    },

    getNetworkOptions: function() {
        return {
            layout: {
                hierarchical: {
                    direction: 'LR',
                    sortMethod: 'directed',
                    levelSeparation: 200,
                    nodeSpacing: 150
                }
            },
            physics: { enabled: false },
            interaction: {
                dragNodes: true,
                dragView: true,
                zoomView: true
            },
            nodes: {
                borderWidth: 2,
                shadow: true
            },
            edges: {
                width: 2,
                smooth: {
                    type: 'cubicBezier',
                    forceDirection: 'horizontal',
                    roundness: 0.4
                }
            }
        };
    },

    setupNetworkEvents: function() {
        if (!this.network) return;

        this.network.on('click', (params) => {
            if (params.nodes.length > 0) {
                this.showNodeDetails(params.nodes[0]);
            }
        });

        this.network.on('doubleClick', (params) => {
            if (params.nodes.length > 0) {
                this.focusOnNode(params.nodes[0]);
            }
        });
    },

    setupControls: function() {
        // Fit network button
        const fitBtn = document.querySelector('[onclick="fitNetwork()"]');
        if (fitBtn) {
            fitBtn.onclick = () => this.fitNetwork();
        }

        // Reset zoom button
        const resetBtn = document.querySelector('[onclick="resetZoom()"]');
        if (resetBtn) {
            resetBtn.onclick = () => this.resetZoom();
        }

        // Export button
        const exportBtn = document.querySelector('[onclick="exportLineage()"]');
        if (exportBtn) {
            exportBtn.onclick = () => this.exportLineage();
        }

        // Refresh button
        const refreshBtn = document.querySelector('[onclick="refreshLineage()"]');
        if (refreshBtn) {
            refreshBtn.onclick = () => this.refreshLineage();
        }
    },

    getNodeShape: function(type) {
        const shapes = {
            'sheet': 'box',
            'column': 'ellipse',
            'target_column': 'diamond'
        };
        return shapes[type] || 'dot';
    },

    getNodeSize: function(type) {
        const sizes = {
            'sheet': 30,
            'column': 20,
            'target_column': 25
        };
        return sizes[type] || 15;
    },

    showNodeDetails: function(nodeId) {
        const node = this.nodes.get(nodeId);
        if (!node) return;

        window.ExcelProcessor.utils.showNotification(
            `<strong>${node.label}</strong><br>Type: ${node.type || 'Unknown'}`,
            'info',
            3000
        );
    },

    focusOnNode: function(nodeId) {
        if (this.network) {
            this.network.focus(nodeId, {
                scale: 1.5,
                animation: {
                    duration: 1000,
                    easingFunction: 'easeInOutQuad'
                }
            });
        }
    },

    fitNetwork: function() {
        if (this.network) {
            this.network.fit({
                animation: {
                    duration: 1000,
                    easingFunction: 'easeInOutQuad'
                }
            });
        }
    },

    resetZoom: function() {
        if (this.network) {
            this.network.moveTo({
                scale: 1.0,
                animation: {
                    duration: 1000,
                    easingFunction: 'easeInOutQuad'
                }
            });
        }
    },

    exportLineage: function() {
        if (!this.network) return;

        try {
            const canvas = this.network.getCanvas();
            const dataURL = canvas.toDataURL('image/png');
            
            const link = document.createElement('a');
            link.download = `lineage_${Date.now()}.png`;
            link.href = dataURL;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            window.ExcelProcessor.utils.showNotification('Lineage exported successfully!', 'success');
        } catch (error) {
            console.error('Export error:', error);
            window.ExcelProcessor.utils.showNotification('Export failed', 'danger');
        }
    },

    refreshLineage: function() {
        window.location.reload();
    },

    showError: function(container) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i data-feather="alert-triangle" class="text-warning mb-3" style="width: 48px; height: 48px;"></i>
                <p class="text-muted">Error loading lineage visualization</p>
            </div>
        `;
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    }
};

// Data Cleaning Component
window.ExcelProcessor.components.DataCleaning = {
    init: function() {
        this.setupCleaningOptions();
        this.setupPreviewControls();
    },

    setupCleaningOptions: function() {
        const customizeBtn = document.querySelector('[onclick="customizecleaning()"]');
        if (customizeBtn) {
            customizeBtn.onclick = () => this.showCustomCleaningModal();
        }

        const applyBtn = document.querySelector('[onclick="applyCustomCleaning()"]');
        if (applyBtn) {
            applyBtn.onclick = () => this.applyCustomCleaning();
        }
    },

    setupPreviewControls: function() {
        const previewBtn = document.querySelector('[onclick="previewMore()"]');
        if (previewBtn) {
            previewBtn.onclick = () => this.previewMoreRows();
        }

        const downloadBtn = document.querySelector('[onclick="applyCleaningAndDownload()"]');
        if (downloadBtn) {
            downloadBtn.onclick = () => this.applyCleaningAndDownload();
        }
    },

    showCustomCleaningModal: function() {
        const modal = new bootstrap.Modal(document.getElementById('customCleaningModal'));
        modal.show();
    },

    applyCustomCleaning: function() {
        const form = document.getElementById('customCleaningForm');
        const formData = new FormData(form);
        
        // Get cleaning options
        const options = {
            removeEmpty: formData.has('removeEmpty'),
            cleanStacked: formData.has('cleanStacked'),
            removeCrossed: formData.has('removeCrossed'),
            standardizeColumns: formData.has('standardizeColumns'),
            autoDataTypes: formData.has('autoDataTypes'),
            handleDates: formData.has('handleDates'),
            handleNumbers: formData.has('handleNumbers'),
            trimWhitespace: formData.has('trimWhitespace')
        };

        window.ExcelProcessor.utils.showLoading('Applying custom cleaning options...');
        
        // Simulate processing (in real implementation, this would be an API call)
        setTimeout(() => {
            window.ExcelProcessor.utils.hideLoading();
            window.ExcelProcessor.utils.showNotification('Custom cleaning applied!', 'success');
            bootstrap.Modal.getInstance(document.getElementById('customCleaningModal')).hide();
        }, 2000);
    },

    previewMoreRows: function() {
        const currentUrl = new URL(window.location);
        currentUrl.searchParams.set('preview_rows', '20');
        window.location.href = currentUrl.toString();
    },

    applyCleaningAndDownload: function() {
        const confirmation = confirm('Apply cleaning operations and download the cleaned data?');
        
        if (confirmation) {
            window.ExcelProcessor.utils.showLoading('Processing and preparing download...');
            
            // Simulate processing
            setTimeout(() => {
                window.ExcelProcessor.utils.hideLoading();
                window.ExcelProcessor.utils.showNotification('Cleaning applied! Download starting...', 'success');
            }, 3000);
        }
    }
};

// Application Initialization
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather Icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }

    // Initialize components based on current page
    const path = window.location.pathname;
    
    if (path.includes('/upload')) {
        window.ExcelProcessor.components.FileUpload.init();
    }
    
    if (path.includes('/sheets') || path.includes('/combine')) {
        window.ExcelProcessor.components.SheetSelection.init();
    }
    
    if (path.includes('/lineage')) {
        // Wait for vis.js to load
        if (typeof vis !== 'undefined') {
            window.ExcelProcessor.components.LineageVisualization.init();
        } else {
            // Retry after a short delay
            setTimeout(() => {
                if (typeof vis !== 'undefined') {
                    window.ExcelProcessor.components.LineageVisualization.init();
                }
            }, 1000);
        }
    }
    
    if (path.includes('/clean')) {
        window.ExcelProcessor.components.DataCleaning.init();
    }

    // Setup global event listeners
    setupGlobalEventListeners();
    
    // Add fade-in animation to main content
    const mainContent = document.querySelector('main');
    if (mainContent) {
        mainContent.classList.add('fade-in');
    }
});

// Global Event Listeners
function setupGlobalEventListeners() {
    // Handle page unload during processing
    window.addEventListener('beforeunload', function(e) {
        if (window.ExcelProcessor.state.uploadInProgress || window.ExcelProcessor.state.processingInProgress) {
            const message = 'Processing is in progress. Are you sure you want to leave?';
            e.returnValue = message;
            return message;
        }
    });

    // Handle keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + U for upload (when not in input field)
        if ((e.ctrlKey || e.metaKey) && e.key === 'u' && !['INPUT', 'TEXTAREA'].includes(e.target.tagName)) {
            e.preventDefault();
            const uploadLink = document.querySelector('a[href*="/upload"]');
            if (uploadLink) {
                uploadLink.click();
            }
        }
        
        // Escape key to close modals
        if (e.key === 'Escape') {
            const openModal = document.querySelector('.modal.show');
            if (openModal) {
                const modal = bootstrap.Modal.getInstance(openModal);
                if (modal) {
                    modal.hide();
                }
            }
        }
    });

    // Handle responsive navigation
    const navbarToggler = document.querySelector('.navbar-toggler');
    if (navbarToggler) {
        navbarToggler.addEventListener('click', function() {
            const navbar = document.querySelector('.navbar-collapse');
            if (navbar) {
                navbar.classList.toggle('show');
            }
        });
    }

    // Auto-refresh feather icons after dynamic content changes
    const observer = new MutationObserver(function(mutations) {
        let shouldRefresh = false;
        mutations.forEach(function(mutation) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                for (let node of mutation.addedNodes) {
                    if (node.nodeType === Node.ELEMENT_NODE && 
                        (node.querySelector && node.querySelector('[data-feather]') || 
                         node.hasAttribute && node.hasAttribute('data-feather'))) {
                        shouldRefresh = true;
                        break;
                    }
                }
            }
        });
        
        if (shouldRefresh && typeof feather !== 'undefined') {
            feather.replace();
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

// Export for global access
window.setupGlobalEventListeners = setupGlobalEventListeners;

// Error handling
window.addEventListener('error', function(e) {
    if (window.ExcelProcessor.config.debug) {
        console.error('Application error:', e.error);
    }
    
    window.ExcelProcessor.utils.showNotification(
        'An unexpected error occurred. Please refresh the page and try again.',
        'danger',
        10000
    );
});

window.addEventListener('unhandledrejection', function(e) {
    if (window.ExcelProcessor.config.debug) {
        console.error('Unhandled promise rejection:', e.reason);
    }
    
    window.ExcelProcessor.utils.showNotification(
        'A network or processing error occurred. Please check your connection and try again.',
        'warning',
        8000
    );
});

// Console welcome message
if (window.ExcelProcessor.config.debug) {
    console.log('%c🔥 Excel Data Processor', 'color: #00695C; font-size: 20px; font-weight: bold;');
    console.log('%cTD Green themed intelligent multi-sheet Excel processing', 'color: #00897B; font-size: 14px;');
    console.log('%cApplication initialized successfully!', 'color: #4CAF50; font-size: 12px;');
}
