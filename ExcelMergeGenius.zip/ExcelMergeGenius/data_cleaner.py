import pandas as pd
import numpy as np
import re
import logging

logger = logging.getLogger(__name__)

class DataCleaner:
    """Handle data cleaning operations"""
    
    def __init__(self):
        self.cleaning_stats = {}
    
    def clean_dataframe(self, df):
        """Main method to clean a dataframe"""
        if df.empty:
            return df
        
        cleaned_df = df.copy()
        self.cleaning_stats = {
            'original_rows': len(df),
            'original_columns': len(df.columns),
            'operations_performed': []
        }
        
        # Apply cleaning operations
        cleaned_df = self._remove_empty_rows_cols(cleaned_df)
        cleaned_df = self._clean_stacked_values(cleaned_df)
        cleaned_df = self._remove_crossed_out_values(cleaned_df)
        cleaned_df = self._standardize_column_names(cleaned_df)
        cleaned_df = self._handle_merged_cell_values(cleaned_df)
        cleaned_df = self._clean_data_types(cleaned_df)
        
        self.cleaning_stats['final_rows'] = len(cleaned_df)
        self.cleaning_stats['final_columns'] = len(cleaned_df.columns)
        
        return cleaned_df
    
    def _remove_empty_rows_cols(self, df):
        """Remove completely empty rows and columns"""
        original_shape = df.shape
        
        # Remove empty rows
        df = df.dropna(how='all')
        
        # Remove empty columns
        df = df.dropna(axis=1, how='all')
        
        if df.shape != original_shape:
            self.cleaning_stats['operations_performed'].append({
                'operation': 'remove_empty',
                'rows_removed': original_shape[0] - df.shape[0],
                'columns_removed': original_shape[1] - df.shape[1]
            })
        
        return df
    
    def _clean_stacked_values(self, df):
        """Clean stacked values in cells (values separated by newlines or special chars)"""
        stacked_patterns = [
            r'\n+',  # Multiple newlines
            r'\r+',  # Carriage returns
            r'[\|\;]{2,}',  # Multiple pipes or semicolons
        ]
        
        operations_count = 0
        
        for col in df.columns:
            if df[col].dtype == 'object':  # Only process text columns
                for pattern in stacked_patterns:
                    # Find cells with stacked values
                    mask = df[col].astype(str).str.contains(pattern, na=False, regex=True)
                    
                    if mask.any():
                        # For stacked values, take the first value
                        df.loc[mask, col] = df.loc[mask, col].astype(str).str.split(pattern).str[0]
                        operations_count += mask.sum()
        
        if operations_count > 0:
            self.cleaning_stats['operations_performed'].append({
                'operation': 'clean_stacked_values',
                'cells_cleaned': operations_count
            })
        
        return df
    
    def _remove_crossed_out_values(self, df):
        """Remove or clean crossed out values (indicated by strikethrough or special markers)"""
        # Patterns that might indicate crossed out text
        crossed_out_patterns = [
            (r'~~(.+?)~~', True),  # Markdown strikethrough - extract content
            (r'<s>(.+?)</s>', True),  # HTML strikethrough - extract content  
            (r'<del>(.+?)</del>', True),  # HTML delete - extract content
            (r'\[DELETED\]', False),  # Explicit deletion marker - remove
            (r'\[CROSSED OUT\]', False),  # Explicit crossed out marker - remove
        ]
        
        operations_count = 0
        
        for col in df.columns:
            if df[col].dtype == 'object':
                for pattern, extract_content in crossed_out_patterns:
                    # Find and clean crossed out text
                    try:
                        mask = df[col].astype(str).str.contains(pattern, na=False, regex=True)
                        
                        if mask.any():
                            if extract_content:
                                # Extract text from strikethrough markup
                                df.loc[mask, col] = df.loc[mask, col].astype(str).str.replace(pattern, r'\1', regex=True)
                            else:
                                # Remove deletion markers
                                df.loc[mask, col] = df.loc[mask, col].astype(str).str.replace(pattern, '', regex=True)
                            
                            operations_count += mask.sum()
                    except Exception:
                        # Skip patterns that cause regex issues
                        continue
        
        if operations_count > 0:
            self.cleaning_stats['operations_performed'].append({
                'operation': 'remove_crossed_out',
                'cells_cleaned': operations_count
            })
        
        return df
    
    def _standardize_column_names(self, df):
        """Standardize column names"""
        original_columns = df.columns.tolist()
        
        new_columns = []
        for col in df.columns:
            # Convert to string and clean
            clean_col = str(col).strip()
            
            # Remove special characters and replace with underscores
            clean_col = re.sub(r'[^\w\s]', '_', clean_col)
            
            # Replace spaces with underscores
            clean_col = re.sub(r'\s+', '_', clean_col)
            
            # Remove multiple consecutive underscores
            clean_col = re.sub(r'_+', '_', clean_col)
            
            # Remove leading/trailing underscores
            clean_col = clean_col.strip('_')
            
            # Ensure column name is not empty
            if not clean_col:
                clean_col = f'Column_{len(new_columns) + 1}'
            
            new_columns.append(clean_col)
        
        # Handle duplicate column names
        final_columns = []
        for col in new_columns:
            if col in final_columns:
                counter = 1
                while f"{col}_{counter}" in final_columns:
                    counter += 1
                final_columns.append(f"{col}_{counter}")
            else:
                final_columns.append(col)
        
        df.columns = final_columns
        
        if original_columns != final_columns:
            self.cleaning_stats['operations_performed'].append({
                'operation': 'standardize_columns',
                'columns_changed': len([i for i, (old, new) in enumerate(zip(original_columns, final_columns)) if old != new])
            })
        
        return df
    
    def _handle_merged_cell_values(self, df):
        """Handle values that might have come from merged cells"""
        operations_count = 0
        
        for col in df.columns:
            if df[col].dtype == 'object':
                # Look for patterns that suggest merged cell content
                # Often these appear as repeated values or values with excessive whitespace
                
                # Remove excessive whitespace
                mask = df[col].astype(str).str.contains(r'\s{3,}', na=False)
                if mask.any():
                    df.loc[mask, col] = df.loc[mask, col].astype(str).str.replace(r'\s+', ' ', regex=True).str.strip()
                    operations_count += mask.sum()
        
        if operations_count > 0:
            self.cleaning_stats['operations_performed'].append({
                'operation': 'handle_merged_cells',
                'cells_cleaned': operations_count
            })
        
        return df
    
    def _clean_data_types(self, df):
        """Clean and optimize data types"""
        operations_count = 0
        
        for col in df.columns:
            original_dtype = df[col].dtype
            
            # Try to convert to more appropriate data types
            if df[col].dtype == 'object':
                # Clean string data first
                df[col] = df[col].astype(str).str.strip()
                
                # Replace common null representations
                null_values = ['', 'NULL', 'null', 'N/A', 'n/a', 'NA', 'na', '#N/A', 'None', 'none']
                df[col] = df[col].replace(null_values, np.nan)
                
                # Try to convert to numeric
                try:
                    numeric_converted = pd.to_numeric(df[col], errors='coerce')
                    valid_count = numeric_converted.count()
                    if valid_count > 0:
                        # If most values can be converted to numeric, do it
                        non_na_ratio = valid_count / len(df)
                        if non_na_ratio > 0.8:  # 80% of values are numeric
                            df[col] = numeric_converted
                            operations_count += 1
                            continue
                except Exception:
                    pass
                
                # Try to convert to datetime
                try:
                    datetime_converted = pd.to_datetime(df[col], errors='coerce')
                    valid_count = datetime_converted.count()
                    if valid_count > 0:
                        non_na_ratio = valid_count / len(df)
                        if non_na_ratio > 0.8:  # 80% of values are dates
                            df[col] = datetime_converted
                            operations_count += 1
                            continue
                except Exception:
                    pass
        
        if operations_count > 0:
            self.cleaning_stats['operations_performed'].append({
                'operation': 'clean_data_types',
                'columns_converted': operations_count
            })
        
        return df
    
    def get_cleaning_report(self):
        """Get a report of cleaning operations performed"""
        return self.cleaning_stats
    
    def detect_data_quality_issues(self, df):
        """Detect potential data quality issues"""
        issues = []
        
        for col in df.columns:
            col_issues = {
                'column': col,
                'issues': []
            }
            
            # Check for high null percentage
            null_pct = (df[col].isna().sum() / len(df)) * 100
            if null_pct > 50:
                col_issues['issues'].append(f'High null percentage: {null_pct:.1f}%')
            
            # Check for duplicate values in what might be ID columns
            if 'id' in col.lower() or 'key' in col.lower():
                duplicate_count = df[col].duplicated().sum()
                if duplicate_count > 0:
                    col_issues['issues'].append(f'Duplicate values in ID column: {duplicate_count}')
            
            # Check for inconsistent formats
            if df[col].dtype == 'object':
                unique_patterns = set()
                for value in df[col].dropna().astype(str):
                    # Create a pattern from the value
                    pattern = re.sub(r'\d', '9', value)
                    pattern = re.sub(r'[a-zA-Z]', 'A', pattern)
                    unique_patterns.add(pattern)
                
                if len(unique_patterns) > 5:  # Many different formats
                    col_issues['issues'].append('Inconsistent data formats detected')
            
            if col_issues['issues']:
                issues.append(col_issues)
        
        return issues
