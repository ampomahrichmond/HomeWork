from app import db
from datetime import datetime
import json

class ExcelFile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    sheet_count = db.Column(db.Integer, default=0)
    status = db.Column(db.String(50), default='uploaded')  # uploaded, processed, error
    
    # Relationships
    sheets = db.relationship('ExcelSheet', backref='excel_file', lazy=True, cascade='all, delete-orphan')

class ExcelSheet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    excel_file_id = db.Column(db.Integer, db.ForeignKey('excel_file.id'), nullable=False)
    sheet_name = db.Column(db.String(255), nullable=False)
    row_count = db.Column(db.Integer, default=0)
    column_count = db.Column(db.Integer, default=0)
    headers = db.Column(db.Text)  # JSON string of headers
    is_selected = db.Column(db.Boolean, default=False)
    
    def get_headers(self):
        """Get headers as a list"""
        if self.headers:
            return json.loads(self.headers)
        return []
    
    def set_headers(self, headers_list):
        """Set headers from a list"""
        self.headers = json.dumps(headers_list)

class ProcessingJob(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    job_name = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(50), default='pending')  # pending, running, completed, error
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    completed_date = db.Column(db.DateTime)
    result_file_path = db.Column(db.String(500))
    error_message = db.Column(db.Text)
    
    # Configuration for the job
    selected_sheets = db.Column(db.Text)  # JSON string of selected sheet IDs
    join_criteria = db.Column(db.Text)  # JSON string of join configuration
    
    def get_selected_sheets(self):
        """Get selected sheets as a list"""
        if self.selected_sheets:
            return json.loads(self.selected_sheets)
        return []
    
    def set_selected_sheets(self, sheets_list):
        """Set selected sheets from a list"""
        self.selected_sheets = json.dumps(sheets_list)
    
    def get_join_criteria(self):
        """Get join criteria as a dict"""
        if self.join_criteria:
            return json.loads(self.join_criteria)
        return {}
    
    def set_join_criteria(self, criteria_dict):
        """Set join criteria from a dict"""
        self.join_criteria = json.dumps(criteria_dict)

class DataLineage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    processing_job_id = db.Column(db.Integer, db.ForeignKey('processing_job.id'), nullable=False)
    source_sheet_id = db.Column(db.Integer, db.ForeignKey('excel_sheet.id'), nullable=False)
    source_column = db.Column(db.String(255), nullable=False)
    target_column = db.Column(db.String(255), nullable=False)
    transformation_type = db.Column(db.String(100))  # join, clean, copy, etc.
    transformation_details = db.Column(db.Text)  # JSON string with details
    
    # Relationships
    processing_job = db.relationship('ProcessingJob', backref='lineage_items')
    source_sheet = db.relationship('ExcelSheet', backref='lineage_items')
    
    def get_transformation_details(self):
        """Get transformation details as a dict"""
        if self.transformation_details:
            return json.loads(self.transformation_details)
        return {}
    
    def set_transformation_details(self, details_dict):
        """Set transformation details from a dict"""
        self.transformation_details = json.dumps(details_dict)
