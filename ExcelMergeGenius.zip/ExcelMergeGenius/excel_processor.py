import pandas as pd
import openpyxl
from openpyxl import load_workbook
import logging

logger = logging.getLogger(__name__)

class ExcelProcessor:
    """Handle Excel file processing operations"""
    
    def __init__(self, file_path):
        self.file_path = file_path
        self.workbook = None
        self._load_workbook()
    
    def _load_workbook(self):
        """Load the Excel workbook"""
        try:
            self.workbook = load_workbook(self.file_path, data_only=True)
        except Exception as e:
            logger.error(f"Error loading workbook {self.file_path}: {str(e)}")
            raise
    
    def get_sheet_names(self):
        """Get all sheet names in the workbook"""
        if self.workbook:
            return self.workbook.sheetnames
        return []
    
    def get_sheets_info(self):
        """Get detailed information about all sheets"""
        sheets_info = []
        
        for sheet_name in self.get_sheet_names():
            try:
                # Use pandas to read the sheet for basic info
                df = pd.read_excel(self.file_path, sheet_name=sheet_name, nrows=0)
                headers = df.columns.tolist()
                
                # Get row count using openpyxl for better performance
                worksheet = self.workbook[sheet_name]
                row_count = worksheet.max_row
                column_count = worksheet.max_column
                
                sheets_info.append({
                    'name': sheet_name,
                    'row_count': row_count,
                    'column_count': column_count,
                    'headers': headers
                })
                
            except Exception as e:
                logger.warning(f"Error processing sheet {sheet_name}: {str(e)}")
                sheets_info.append({
                    'name': sheet_name,
                    'row_count': 0,
                    'column_count': 0,
                    'headers': [],
                    'error': str(e)
                })
        
        return sheets_info
    
    def get_sheet_data(self, sheet_name):
        """Get full data from a specific sheet"""
        try:
            df = pd.read_excel(self.file_path, sheet_name=sheet_name)
            return df
        except Exception as e:
            logger.error(f"Error reading sheet {sheet_name}: {str(e)}")
            return pd.DataFrame()
    
    def get_sheet_preview(self, sheet_name, rows=10):
        """Get preview data from a specific sheet"""
        try:
            df = pd.read_excel(self.file_path, sheet_name=sheet_name, nrows=rows)
            
            # Convert to dict for template rendering
            preview_data = {
                'headers': df.columns.tolist(),
                'rows': df.values.tolist(),
                'total_rows': len(df),
                'total_columns': len(df.columns)
            }
            
            return preview_data
            
        except Exception as e:
            logger.error(f"Error getting preview for sheet {sheet_name}: {str(e)}")
            return {
                'headers': [],
                'rows': [],
                'total_rows': 0,
                'total_columns': 0,
                'error': str(e)
            }
    
    def detect_merged_cells(self, sheet_name):
        """Detect merged cells in a sheet"""
        try:
            worksheet = self.workbook[sheet_name]
            merged_ranges = []
            
            for merged_range in worksheet.merged_cells.ranges:
                merged_ranges.append({
                    'range': str(merged_range),
                    'top_left': merged_range.start_cell,
                    'bottom_right': merged_range.end_cell
                })
            
            return merged_ranges
            
        except Exception as e:
            logger.error(f"Error detecting merged cells in {sheet_name}: {str(e)}")
            return []
    
    def get_cell_styles(self, sheet_name, max_rows=100):
        """Get cell styles to identify crossed out or special formatting"""
        try:
            worksheet = self.workbook[sheet_name]
            styled_cells = []
            
            for row in worksheet.iter_rows(max_row=min(max_rows, worksheet.max_row)):
                for cell in row:
                    if cell.value is not None:
                        cell_info = {
                            'coordinate': cell.coordinate,
                            'value': cell.value,
                            'has_strike': cell.font.strike if cell.font else False,
                            'is_bold': cell.font.bold if cell.font else False,
                            'fill_color': cell.fill.start_color.index if cell.fill and hasattr(cell.fill, 'start_color') else None
                        }
                        
                        # Only add cells with special formatting
                        if cell_info['has_strike'] or cell_info['is_bold'] or cell_info['fill_color']:
                            styled_cells.append(cell_info)
            
            return styled_cells
            
        except Exception as e:
            logger.error(f"Error getting cell styles for {sheet_name}: {str(e)}")
            return []
    
    def identify_data_types(self, sheet_name):
        """Identify data types in each column"""
        try:
            df = self.get_sheet_data(sheet_name)
            
            column_types = {}
            for column in df.columns:
                dtype = str(df[column].dtype)
                
                # More detailed type analysis
                non_null_values = df[column].dropna()
                if len(non_null_values) > 0:
                    # Check for specific patterns
                    if non_null_values.astype(str).str.match(r'^\d{4}-\d{2}-\d{2}').any():
                        column_types[column] = 'date'
                    elif non_null_values.astype(str).str.match(r'^\d+\.\d+$').any():
                        column_types[column] = 'decimal'
                    elif non_null_values.astype(str).str.match(r'^\d+$').any():
                        column_types[column] = 'integer'
                    elif non_null_values.astype(str).str.contains('@').any():
                        column_types[column] = 'email'
                    else:
                        column_types[column] = 'text'
                else:
                    column_types[column] = 'empty'
            
            return column_types
            
        except Exception as e:
            logger.error(f"Error identifying data types for {sheet_name}: {str(e)}")
            return {}
    
    def find_potential_join_columns(self, sheet_names):
        """Find potential columns for joining between sheets"""
        try:
            sheets_columns = {}
            
            # Get column information for each sheet
            for sheet_name in sheet_names:
                df = self.get_sheet_data(sheet_name)
                sheets_columns[sheet_name] = {
                    'columns': df.columns.tolist(),
                    'types': self.identify_data_types(sheet_name)
                }
            
            # Find common column names
            all_columns = set()
            for sheet_info in sheets_columns.values():
                all_columns.update(sheet_info['columns'])
            
            potential_joins = []
            for column in all_columns:
                sheets_with_column = []
                for sheet_name, sheet_info in sheets_columns.items():
                    if column in sheet_info['columns']:
                        sheets_with_column.append({
                            'sheet': sheet_name,
                            'type': sheet_info['types'].get(column, 'unknown')
                        })
                
                if len(sheets_with_column) >= 2:
                    potential_joins.append({
                        'column_name': column,
                        'sheets': sheets_with_column,
                        'join_potential': 'high' if len(sheets_with_column) == len(sheet_names) else 'medium'
                    })
            
            return potential_joins
            
        except Exception as e:
            logger.error(f"Error finding potential join columns: {str(e)}")
            return []
