import json
from models import DataLineage, ProcessingJob, ExcelSheet
from app import db
import logging

logger = logging.getLogger(__name__)

class LineageTracker:
    """Track data lineage throughout processing operations"""
    
    def __init__(self):
        pass
    
    def track_cleaning(self, job_id, sheet_id, original_columns, cleaned_columns):
        """Track lineage for data cleaning operations"""
        try:
            # Create lineage records for column mappings
            for orig_col in original_columns:
                if orig_col in cleaned_columns:
                    # Column was preserved
                    lineage = DataLineage(
                        processing_job_id=job_id,
                        source_sheet_id=sheet_id,
                        source_column=orig_col,
                        target_column=orig_col,
                        transformation_type='clean'
                    )
                    lineage.set_transformation_details({
                        'operation': 'data_cleaning',
                        'preserved': True,
                        'original_name': orig_col
                    })
                    db.session.add(lineage)
                else:
                    # Column was removed or transformed
                    lineage = DataLineage(
                        processing_job_id=job_id,
                        source_sheet_id=sheet_id,
                        source_column=orig_col,
                        target_column='[REMOVED]',
                        transformation_type='clean'
                    )
                    lineage.set_transformation_details({
                        'operation': 'data_cleaning',
                        'preserved': False,
                        'reason': 'removed_during_cleaning'
                    })
                    db.session.add(lineage)
            
            # Track any new columns created during cleaning
            for clean_col in cleaned_columns:
                if clean_col not in original_columns:
                    lineage = DataLineage(
                        processing_job_id=job_id,
                        source_sheet_id=sheet_id,
                        source_column=None,
                        target_column=clean_col,
                        transformation_type='clean'
                    )
                    lineage.set_transformation_details({
                        'operation': 'data_cleaning',
                        'created': True,
                        'reason': 'created_during_cleaning'
                    })
                    db.session.add(lineage)
            
            db.session.commit()
            
        except Exception as e:
            logger.error(f"Error tracking cleaning lineage: {str(e)}")
            db.session.rollback()
    
    def track_join(self, job_id, sheet_id, join_columns, join_type):
        """Track lineage for join operations"""
        try:
            for join_col in join_columns:
                lineage = DataLineage(
                    processing_job_id=job_id,
                    source_sheet_id=sheet_id,
                    source_column=join_col,
                    target_column=join_col,
                    transformation_type='join'
                )
                lineage.set_transformation_details({
                    'operation': 'join',
                    'join_type': join_type,
                    'join_column': join_col,
                    'role': 'join_key'
                })
                db.session.add(lineage)
            
            db.session.commit()
            
        except Exception as e:
            logger.error(f"Error tracking join lineage: {str(e)}")
            db.session.rollback()
    
    def track_concatenation(self, job_id, sheet_id):
        """Track lineage for concatenation operations"""
        try:
            # Get sheet information
            sheet = ExcelSheet.query.get(sheet_id)
            if not sheet:
                return
            
            headers = sheet.get_headers()
            
            for header in headers:
                lineage = DataLineage(
                    processing_job_id=job_id,
                    source_sheet_id=sheet_id,
                    source_column=header,
                    target_column=header,
                    transformation_type='concatenate'
                )
                lineage.set_transformation_details({
                    'operation': 'concatenation',
                    'source_sheet': sheet.sheet_name
                })
                db.session.add(lineage)
            
            db.session.commit()
            
        except Exception as e:
            logger.error(f"Error tracking concatenation lineage: {str(e)}")
            db.session.rollback()
    
    def get_job_lineage(self, job_id):
        """Get all lineage information for a job"""
        try:
            lineage_items = DataLineage.query.filter_by(processing_job_id=job_id).all()
            
            lineage_data = {
                'transformations': {},
                'column_mappings': [],
                'sheets_involved': set()
            }
            
            for item in lineage_items:
                # Track transformation types
                if item.transformation_type not in lineage_data['transformations']:
                    lineage_data['transformations'][item.transformation_type] = 0
                lineage_data['transformations'][item.transformation_type] += 1
                
                # Track column mappings
                lineage_data['column_mappings'].append({
                    'source_sheet': item.source_sheet.sheet_name if item.source_sheet else None,
                    'source_column': item.source_column,
                    'target_column': item.target_column,
                    'transformation_type': item.transformation_type,
                    'details': item.get_transformation_details()
                })
                
                # Track sheets involved
                if item.source_sheet:
                    lineage_data['sheets_involved'].add(item.source_sheet.sheet_name)
            
            lineage_data['sheets_involved'] = list(lineage_data['sheets_involved'])
            
            return lineage_data
            
        except Exception as e:
            logger.error(f"Error getting job lineage: {str(e)}")
            return {'transformations': {}, 'column_mappings': [], 'sheets_involved': []}
    
    def generate_lineage_graph(self, job_id):
        """Generate data for lineage visualization"""
        try:
            lineage_data = self.get_job_lineage(job_id)
            
            # Create nodes and edges for visualization
            nodes = []
            edges = []
            node_id_map = {}
            
            # Create nodes for sheets
            for sheet_name in lineage_data['sheets_involved']:
                node_id = f"sheet_{len(nodes)}"
                nodes.append({
                    'id': node_id,
                    'label': sheet_name,
                    'type': 'sheet',
                    'color': '#4CAF50'
                })
                node_id_map[sheet_name] = node_id
            
            # Create nodes for columns and edges for transformations
            column_nodes = {}
            
            for mapping in lineage_data['column_mappings']:
                source_sheet = mapping['source_sheet']
                source_column = mapping['source_column']
                target_column = mapping['target_column']
                transformation_type = mapping['transformation_type']
                
                # Create source column node if it doesn't exist
                if source_column and source_sheet:
                    source_key = f"{source_sheet}.{source_column}"
                    if source_key not in column_nodes:
                        node_id = f"col_{len(nodes)}"
                        nodes.append({
                            'id': node_id,
                            'label': source_column,
                            'type': 'column',
                            'sheet': source_sheet,
                            'color': '#2196F3'
                        })
                        column_nodes[source_key] = node_id
                
                # Create target column node if it doesn't exist
                if target_column:
                    target_key = f"target.{target_column}"
                    if target_key not in column_nodes:
                        node_id = f"col_{len(nodes)}"
                        nodes.append({
                            'id': node_id,
                            'label': target_column,
                            'type': 'target_column',
                            'color': '#FF9800'
                        })
                        column_nodes[target_key] = node_id
                
                # Create edges
                if source_column and target_column and source_sheet:
                    source_key = f"{source_sheet}.{source_column}"
                    target_key = f"target.{target_column}"
                    
                    if source_key in column_nodes and target_key in column_nodes:
                        edges.append({
                            'from': column_nodes[source_key],
                            'to': column_nodes[target_key],
                            'label': transformation_type,
                            'color': self._get_transformation_color(transformation_type)
                        })
                
                # Create edge from sheet to column
                if source_sheet and source_column:
                    source_key = f"{source_sheet}.{source_column}"
                    if source_sheet in node_id_map and source_key in column_nodes:
                        edges.append({
                            'from': node_id_map[source_sheet],
                            'to': column_nodes[source_key],
                            'color': '#E0E0E0'
                        })
            
            return {
                'nodes': nodes,
                'edges': edges,
                'stats': lineage_data['transformations']
            }
            
        except Exception as e:
            logger.error(f"Error generating lineage graph: {str(e)}")
            return {'nodes': [], 'edges': [], 'stats': {}}
    
    def _get_transformation_color(self, transformation_type):
        """Get color for transformation type"""
        colors = {
            'clean': '#4CAF50',
            'join': '#2196F3',
            'concatenate': '#FF9800',
            'copy': '#9C27B0'
        }
        return colors.get(transformation_type, '#757575')
    
    def export_lineage_report(self, job_id):
        """Export lineage information as a structured report"""
        try:
            job = ProcessingJob.query.get(job_id)
            lineage_data = self.get_job_lineage(job_id)
            
            report = {
                'job_info': {
                    'id': job.id,
                    'name': job.job_name,
                    'status': job.status,
                    'created_date': job.created_date.isoformat() if job.created_date else None,
                    'completed_date': job.completed_date.isoformat() if job.completed_date else None
                },
                'lineage_summary': {
                    'sheets_processed': len(lineage_data['sheets_involved']),
                    'transformations_applied': lineage_data['transformations'],
                    'total_column_mappings': len(lineage_data['column_mappings'])
                },
                'detailed_lineage': lineage_data['column_mappings']
            }
            
            return report
            
        except Exception as e:
            logger.error(f"Error exporting lineage report: {str(e)}")
            return None
